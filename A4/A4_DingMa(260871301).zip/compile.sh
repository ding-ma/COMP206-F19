#!/bin/bash

# Mame: Ding Ma
#ID: 260871301

# compiles matrix
gcc matrix.c -o matrix

# compiles reverse
gcc reverse.c -o reverse