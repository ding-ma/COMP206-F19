//
// Created by dingm on 2019-11-21.
//

#ifndef COMP206_A6_SSV_H
#define COMP206_A6_SSV_H
void parse(char record[], int *acct, float *amnt);
#endif //COMP206_A6_SSV_H
